﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class GradeDistributionData
    {

        public List<Coursework> listCW { set; get; }


        public GradeDistributionData(List<Coursework> listCW)
        {
            this.listCW = listCW;
        }

        public int getOverall_m_0_9() {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++) {
                returnData += listCW[i].m_0_9;
            }
            return returnData;
        }

        public int getOverall_m_10_19()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_10_19;
            }
            return returnData;
        }
        
        public int getOverall_m_20_29()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_20_29;
            }
            return returnData;
        }

        public int getOverall_m_30_39()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_30_39;
            }
            return returnData;
        }

        public int getOverall_m_40_49()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_40_49;
            }
            return returnData;
        }

        public int getOverall_m_50_59()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_50_59;
            }
            return returnData;
        }

        public int getOverall_m_60_69()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_60_69;
            }
            return returnData;
        }

        public int getOverall_m_70_79()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_70_79;
            }
            return returnData;
        }

        public int getOverall_m_80_89()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_80_89;
            }
            return returnData;
        }

        public int getOverall_m_90()
        {
            int size = listCW.Count;
            int returnData = 0;
            for (var i = 0; i < size; i++)
            {
                returnData += listCW[i].m_90;
            }
            return returnData;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class CMR
    {
        public String academicSession { set; get; }
        public String courseCode { set; get; }
        public String courseLeader { set; get; }
        public int studentCount { set; get; }


        public CMR(String academicSession, String courseCode, String courseLeader, int studentCount) {
            this.academicSession = academicSession;
            this.courseCode = courseCode;
            this.courseLeader = courseLeader;
            this.studentCount = studentCount;
        }


    }
}

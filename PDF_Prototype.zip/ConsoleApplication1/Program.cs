﻿using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using PdfSharp.Pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Document doc = createDocument();
            createTable(doc);
            saveDocument(doc);
        }

        private static Document createDocument()
        {

            Document doc = new Document();
            doc.AddSection();
            return doc;
        }

        private static void createTable(Document doc)
        {
            CMR cmr = new CMR("Academic Session", "XYZ", "Phuong Tran", 20);
            Table table = createCMRTBL(cmr);
            doc.LastSection.Add(table);
            addBreakLine(doc);
            List<Coursework> listCW = new List<Coursework>();
            listCW.Add(new Coursework(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
            listCW.Add(new Coursework(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
            listCW.Add(new Coursework(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
            listCW.Add(new Coursework(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
            GradeDistributionData gdd = new GradeDistributionData(listCW);
            Table statisticalDataTBL = createStatisticalTBL(gdd);
            doc.LastSection.Add(statisticalDataTBL);
            addBreakLine(doc);
            Table generalCommentTBL = createGeneralCmtTBL();
            doc.LastSection.Add(generalCommentTBL);
            addBreakLine(doc);
            Table actionToBeTakenTBL = createActionTBTTBL();
            doc.LastSection.Add(actionToBeTakenTBL);
        }

        private static Table createCMRTBL(CMR cmr) {
            Table table = new Table();
            table.Borders.Width = 0.75;
            table.Borders.Color = Color.Parse("0x3F849B");
            table.AddColumn(Unit.FromCentimeter(5));
            table.AddColumn(Unit.FromCentimeter(12));

            Row row = table.AddRow();
            Cell cell = row.Cells[0];
            cell.AddParagraph("COURSE MONITORING REPORT");
            cell.Format.Font.Size = 18;
            row.Cells[0].MergeRight = 1;
            row.Cells[0].Format.Alignment = ParagraphAlignment.Center;

            row = table.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("Academic Session");
            cell = row.Cells[1];
            cell.AddParagraph(cmr.academicSession);

            row = table.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("Course Code + title:");
            cell = row.Cells[1];
            cell.AddParagraph(cmr.courseCode);

            row = table.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("Course Leader:");
            cell = row.Cells[1];
            cell.AddParagraph(cmr.courseLeader);

            row = table.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("Student count");
            cell = row.Cells[1];
            cell.AddParagraph(cmr.studentCount.ToString());

            return table;
        }

        private static Table createStatisticalTBL(GradeDistributionData gdd) {
            Table statisticalDataTBL = new Table();
            statisticalDataTBL.Borders.Color = Color.Parse("0x3F849B");
            statisticalDataTBL.Borders.Width = 0.75;
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(2));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));
            statisticalDataTBL.AddColumn(Unit.FromCentimeter(1.54));

            Row row = statisticalDataTBL.AddRow();
            Cell cell = row.Cells[0];
            cell.AddParagraph("Grade Distribution Data");
            cell.Format.Font.Bold = true;
            row.Cells[0].MergeRight = 10;

            // Header
            row = statisticalDataTBL.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("");
            cell = row.Cells[1];
            cell.AddParagraph("0-9");
            cell = row.Cells[2];
            cell.AddParagraph("10-19");
            cell = row.Cells[3];
            cell.AddParagraph("20-29");
            cell = row.Cells[4];
            cell.AddParagraph("30-39");
            cell = row.Cells[5];
            cell.AddParagraph("40-49");
            cell = row.Cells[6];
            cell.AddParagraph("50-59");
            cell = row.Cells[7];
            cell.AddParagraph("60-69");
            cell = row.Cells[8];
            cell.AddParagraph("70-79");
            cell = row.Cells[9];
            cell.AddParagraph("80-89");
            cell = row.Cells[10];
            cell.AddParagraph("90+");

            // Loop through list cw
            int size = gdd.listCW.Count;

            // Loop for rows
            for (var i = 0; i < size; i++) {
                row = statisticalDataTBL.AddRow();
                cell = row.Cells[0];
                cell.AddParagraph("CW1");
                cell = row.Cells[1];
                cell.AddParagraph(gdd.listCW[i].m_0_9.ToString());
                cell = row.Cells[2];
                cell.AddParagraph(gdd.listCW[i].m_10_19.ToString());
                cell = row.Cells[3];
                cell.AddParagraph(gdd.listCW[i].m_20_29.ToString());
                cell = row.Cells[4];
                cell.AddParagraph(gdd.listCW[i].m_30_39.ToString());
                cell = row.Cells[5];
                cell.AddParagraph(gdd.listCW[i].m_40_49.ToString());
                cell = row.Cells[6];
                cell.AddParagraph(gdd.listCW[i].m_50_59.ToString());
                cell = row.Cells[7];
                cell.AddParagraph(gdd.listCW[i].m_60_69.ToString());
                cell = row.Cells[8];
                cell.AddParagraph(gdd.listCW[i].m_70_79.ToString());
                cell = row.Cells[9];
                cell.AddParagraph(gdd.listCW[i].m_80_89.ToString());
                cell = row.Cells[10];
                cell.AddParagraph(gdd.listCW[i].m_90.ToString());
            }


            row = statisticalDataTBL.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("EX");

            row = statisticalDataTBL.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("OVERALL");
            cell = row.Cells[1];
            cell.AddParagraph(gdd.getOverall_m_0_9().ToString());
            cell = row.Cells[2];
            cell.AddParagraph(gdd.getOverall_m_10_19().ToString());
            cell = row.Cells[3];
            cell.AddParagraph(gdd.getOverall_m_20_29().ToString());
            cell = row.Cells[4];
            cell.AddParagraph(gdd.getOverall_m_30_39().ToString());
            cell = row.Cells[5];
            cell.AddParagraph(gdd.getOverall_m_40_49().ToString());
            cell = row.Cells[6];
            cell.AddParagraph(gdd.getOverall_m_50_59().ToString());
            cell = row.Cells[7];
            cell.AddParagraph(gdd.getOverall_m_60_69().ToString());
            cell = row.Cells[8];
            cell.AddParagraph(gdd.getOverall_m_70_79().ToString());
            cell = row.Cells[9];
            cell.AddParagraph(gdd.getOverall_m_80_89().ToString());
            cell = row.Cells[10];
            cell.AddParagraph(gdd.getOverall_m_90().ToString());

            return statisticalDataTBL;
        }

        private static Table createGeneralCmtTBL() {
            Table generalCommentTBL = new Table();
            generalCommentTBL.Borders.Width = 0.75;
            generalCommentTBL.Borders.Color = Color.Parse("0x3F849B");
            generalCommentTBL.AddColumn(Unit.FromCentimeter(17));

            Row row = generalCommentTBL.AddRow();
            Cell cell = row.Cells[0];
            cell.Shading.Color = Color.FromRgbColor(255, Color.Parse("0xDCEEF3"));
            cell.AddParagraph("General comments\n").Format.Font.Bold = true;
            cell.AddParagraph("When you complete this section, at a minimum, you should address the following:\n"
                + "1. The overview of the Course Leader (to include; comments on available statistics, the range of marks, assessment diet and any issues affecting the delivery of the course this year). \n"
                + "2. Student Evaluation and Feedback.\n"
                + "3. Comments of the External Examiner.\n"
                + "4. A review of the previous year’s action plan.");

            row = generalCommentTBL.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("\n\n\n\n\n\n\n\n\n\n");
            return generalCommentTBL;
        }

        private static Table createActionTBTTBL() {
            Table actionToBeTakenTBL = new Table();
            actionToBeTakenTBL.Borders.Width = 0.75;
            actionToBeTakenTBL.Borders.Color = Color.Parse("0x3F849B");
            actionToBeTakenTBL.AddColumn(Unit.FromCentimeter(17));

            Row row = actionToBeTakenTBL.AddRow();
            Cell cell = row.Cells[0];
            cell.Shading.Color = Color.FromRgbColor(255, Color.Parse("0xDCEEF3"));
            cell.AddParagraph("Action to be taken");
            cell.Format.Font.Bold = true;
            row = actionToBeTakenTBL.AddRow();
            cell = row.Cells[0];
            cell.AddParagraph("\n\n\n\n\n\n\n\n\n\n");

            return actionToBeTakenTBL;
        }

        private static void addBreakLine(Document doc) {
            Paragraph paragraph = doc.LastSection.AddParagraph();
            paragraph.AddLineBreak();
        }

        private static void saveDocument(Document doc)
        {
            const bool unicode = true;
            const PdfFontEmbedding embedding = PdfFontEmbedding.Always;
            PdfDocumentRenderer pdfRenderer = new PdfDocumentRenderer(unicode, embedding);
            pdfRenderer.Document = doc;
            pdfRenderer.RenderDocument();
            const string filename = "HelloWorld.pdf";
            pdfRenderer.PdfDocument.Save(filename);
            Console.WriteLine("saved");
        }
    }
}

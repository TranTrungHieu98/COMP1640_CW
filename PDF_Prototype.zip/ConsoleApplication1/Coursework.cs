﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Coursework
    {

        public int m_0_9 { set; get; }
        public int m_10_19 { set; get; }
        public int m_20_29 { set; get; }
        public int m_30_39 { set; get; }
        public int m_40_49 { set; get; }
        public int m_50_59 { set; get; }
        public int m_60_69 { set; get; }
        public int m_70_79 { set; get; }
        public int m_80_89 { set; get; }
        public int m_90 { set; get; }

        public Coursework(int m_0_9, int m_10_19, int m_20_29, int m_30_39, int m_40_49, int m_50_59, int m_60_69, int m_70_79, int m_80_89, int m_90)
        {
            this.m_0_9 = m_0_9;
            this.m_10_19 = m_10_19;
            this.m_20_29 = m_20_29;
            this.m_30_39 = m_30_39;
            this.m_40_49 = m_40_49;
            this.m_50_59 = m_50_59;
            this.m_60_69 = m_60_69;
            this.m_70_79 = m_70_79;
            this.m_80_89 = m_80_89;
            this.m_90 = m_90;
        }

    }
}
